import greenfoot.*;  

public class Path  extends Actor
{
    
    public void act() 
    {
        // Add your action code here.
    }    
}
