import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)


public class Tank extends Mobil
{
    
    public void act() 
    {
        
    } 
    public void accelerate(int rate){
        if(rate <= 0){
            changeGear(1);
        }else if(rate >=0 && rate<=40){
           
            changeGear(1);
            
        }else if(rate>40 && rate <=90){
            changeGear(2);
            
        }else if(rate >90 && rate<=140){
            changeGear(3);
            
        }else if(rate>140 && rate<=200)
        {
            changeGear(4);
            
        }else if(rate>200 && rate<=300)
        {
            changeGear(5);
            
        }else{
            changeGear(6);
            
        }
        
    }
}
