import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public class Mobil extends Kendaraan
{
    private int currentGear;
    private int gigi;
    public void act() 
    {
        // Add your action code here.
        
    }  
    public int getGigi(){
        return gigi;
    }
    public void changeGear(int currentGear) {
        //this.currentGear = currentGear;
        ((CarWorld) getWorld()).addGear(currentGear);
    }

    public void changeVelocity(int speed) {
        ((CarWorld) getWorld()).addSpeed(speed);
    }
}
