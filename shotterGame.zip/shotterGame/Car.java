import greenfoot.*;


public class Car extends Actor
{
    private Actor collidedVehicle;
    private Actor collidedBackground;
    private int counter = 0;
    
    public void act() 
    {
        checkPosition();
        checkKeyAndMove();
        createBomb();
        checkCollision(); 
        click();
    }
    public void checkKeyAndMove()
    {
       
       if(((CarWorld) getWorld()).getPause() == false)
       {
          if(getX()<400)
          {
             //((CarWorld) getWorld()).addSpeed(2);
             if (Greenfoot.isKeyDown("right"))    
             {
                setLocation( getX()+2, getY() );
                ((CarWorld) getWorld()).addSpeed(-1);
             }
             if (Greenfoot.isKeyDown("left"))    
             {
                setLocation( getX()-2, getY() );
                ((CarWorld) getWorld()).addSpeed(-1);
             }
          }
          else
          {
             if (Greenfoot.isKeyDown("right"))    
             {
                setLocation( getX()+(1/5), getY() );
                ((CarWorld) getWorld()).addSpeed(-1);
             }
             if (Greenfoot.isKeyDown("left"))    
             {
                setLocation( getX()-(1/5), getY() );
                ((CarWorld) getWorld()).addSpeed(-1);
             }
          }
          if(getX()>215)
          {
             if (Greenfoot.isKeyDown("right"))    
             {
                setLocation( getX()+2, getY() );
                ((CarWorld) getWorld()).addSpeed(-1);
             }
             if (Greenfoot.isKeyDown("left"))    
             {
                setLocation( getX()-2, getY() );
                ((CarWorld) getWorld()).addSpeed(-1);
             }
          }
          else
          {
             if (Greenfoot.isKeyDown("right"))    
             {
                setLocation( getX()+(1/5), getY() );
                ((CarWorld) getWorld()).addSpeed(-1);
             }
             if (Greenfoot.isKeyDown("left"))    
             {
                setLocation( getX()-(1/5), getY() );
                ((CarWorld) getWorld()).addSpeed(-1);
             }
          }
       }
    }
    
    public void checkPosition()
    {
        CountSpeed value = new CountSpeed();
        
        if(getX()>190 && getX()<420)
        {
            ((CarWorld) getWorld()).addSpeed(1);
        }else
        {
            ((CarWorld) getWorld()).addSpeed(-1);
        }
    }
    public void createBomb()
    {
       if(((CarWorld) getWorld()).getPause() == false)
       {
          if(counter == 0)
          {
             if (Greenfoot.isKeyDown("space"))
             {
                getWorld().addObject(new Bomb(),getX(),getY());
                counter = 20;
             }
          }
          else
          {
             counter--;
          }
       }
    }
    public void checkCollision()
    {
        collidedVehicle = getOneIntersectingObject(Vehicle.class);
        collidedBackground = getOneIntersectingObject(Background.class);
        if (collidedVehicle != null)
        {
           getWorld().removeObject(collidedVehicle);
           ((CarWorld) getWorld()).collided();
           Greenfoot.playSound("Explosion.wav");
        }
        if(collidedBackground != null)
        {
           getWorld().removeObject(collidedBackground);
           ((CarWorld) getWorld()).collided();
           Greenfoot.playSound("Explosion.wav");
        }
    }
    public void click()
    {
       if(Greenfoot.mouseClicked(null))
       {
          if(((CarWorld) getWorld()).getPause() == false)
          {
             ((CarWorld) getWorld()).pauseGame(true);
             getWorld().addObject(new Information(),300,300);
          }
       }
    }
   
}
