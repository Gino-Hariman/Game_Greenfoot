import greenfoot.*;  

public class Kendaraan extends Actor
{
    private int currentVelocity;
    public void act() 
    {
        
    }    
    public Kendaraan() {
                
        this.currentVelocity = 0;
    }
    public int getCurrentVelocity() {
        return currentVelocity;
    }
    
}
