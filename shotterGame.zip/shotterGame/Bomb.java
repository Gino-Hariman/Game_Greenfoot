import greenfoot.*;  


public class Bomb  extends Actor
{
    private GreenfootImage image1;
    private GreenfootImage image2;
    private Actor collidedVehicle;
    
    private Actor collidedBackground;
    public Bomb()
    {
       image1 = new GreenfootImage("explosion.png");
       image2 = new GreenfootImage("explosion-big.png");
    }
   
    public void act() 
    {
       moveUp();
       check();
    }    
    public void moveUp()
    {
       if(((CarWorld) getWorld()).getPause() == false)
       {
          setLocation(getX(), getY()-7);
       }
    }
    public void check()
    {
       collidedVehicle = getOneIntersectingObject(Vehicle.class);
       
       collidedBackground = getOneIntersectingObject(Background.class);
       if(collidedVehicle != null || collidedBackground != null || getY() == 0)
       {
          Greenfoot.playSound("Explosion.wav");
          if(collidedVehicle != null)
          {
             ((CarWorld) getWorld()).addScore(50);
             getWorld().removeObject(collidedVehicle);
          }
          if(collidedBackground != null)
          {
             ((CarWorld) getWorld()).addScore(75);
             getWorld().removeObject(collidedBackground);
          }
          
          getWorld().removeObject(this);
       }
    }
}
