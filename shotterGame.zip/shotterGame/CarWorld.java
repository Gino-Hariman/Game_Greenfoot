import greenfoot.*;

public class CarWorld extends World
{
    private int counter;
    private int lives;
    private int score;
    private boolean pause;
    private int speed;
    private int gear;
    private GreenfootSound music = new GreenfootSound("Tokyo Drift1.mp3");
     /**
     * Constructor for objects of class CarWorld.
     * 
     */
    public CarWorld()
    {
        super(600, 600, 1);
        setPaintOrder(Information.class, ScoreBoard.class, Dot.class, Path.class, Car.class, Bomb.class, Vehicle.class,
        EndLine.class, Line.class, Counter.class, CountSpeed.class,Gear.class, Lives.class, Background.class);
        
        //started(); 
        lives = 3;
        score = 0;
        pause = true;
        addObject(new Car(),305,550);
        addObject(new Counter("Score: "),100,550);
        addObject(new CountSpeed(" /km"), 520, 500);
        addObject(new Gear("Gear : "),530, 550); 
        addObject(new Lives(),50,50);
        addObject(new Lives(),100,50);
        addObject(new Lives(),150,50);
        addObject(new Dot(), 25, 395);
        addObject(new Path(), 25, 250);
        addObject(new Line(),300,0);
        addObject(new Line(),300,90);
        addObject(new Line(),300,180);
        addObject(new Line(),300,270);
        addObject(new Line(),300,360);
        addObject(new Line(),300,450);
        addObject(new Line(),300,540);
        addObject(new Background(), Greenfoot.getRandomNumber(150), Greenfoot.getRandomNumber(600));
        addObject(new Background(), Greenfoot.getRandomNumber(150), Greenfoot.getRandomNumber(600));
        addObject(new Background(), Greenfoot.getRandomNumber(150), Greenfoot.getRandomNumber(600));
        addObject(new Background(), Greenfoot.getRandomNumber(150), Greenfoot.getRandomNumber(600));
        addObject(new Background(), Greenfoot.getRandomNumber(150), Greenfoot.getRandomNumber(600));
        addObject(new Background(), Greenfoot.getRandomNumber(150)+450, Greenfoot.getRandomNumber(600));
        addObject(new Background(), Greenfoot.getRandomNumber(150)+450, Greenfoot.getRandomNumber(600));
        addObject(new Background(), Greenfoot.getRandomNumber(150)+450, Greenfoot.getRandomNumber(600));
        addObject(new Background(), Greenfoot.getRandomNumber(150)+450, Greenfoot.getRandomNumber(600));
        addObject(new Background(), Greenfoot.getRandomNumber(150)+450, Greenfoot.getRandomNumber(600));
        addObject(new Information(),300,300);
    }
    public void act()
    {
       if(pause == false)
       {
          chanceToVehicle();
          chanceToBackground();
          setCounter();
       }
    }
    public void started()
    {
        music.playLoop();
    }   
 
    public void stopped()
    {
        music.stop();
    }
    public void chanceToBackground()
    {
       if(Greenfoot.getRandomNumber(50)<1)
       {
          addObject(new Background(), Greenfoot.getRandomNumber(150), 0);
       }
       if(Greenfoot.getRandomNumber(50)<1)
       {
          addObject(new Background(), Greenfoot.getRandomNumber(150)+450, 0);
       }
    }
    public void chanceToVehicle()
    {
       if(Greenfoot.getRandomNumber(100)<1)
       {
          addObject(new Vehicle(), Greenfoot.getRandomNumber(185)+215, 0);
       }
    }
    public void setCounter()
    {
       counter++;
       if (counter == 23)
       {
         addObject(new Line(),300,0);
         counter = 0;
       }
    }
   
    public int getScore()
    {
       return score;
    }
    public int getGear()
    {
        return gear;
    }
    public int getSpeed(){
        return speed;
    }
    public void addScore(int scoreToAdd)
    {
       score += scoreToAdd;
    }
    public void addGear(int changeGear)
    {
        this.gear = changeGear;
    }
    public void addSpeed(int speedToAdd)
    {
        speed += speedToAdd;
    }
    public int getLives()
    {
       return lives;
    }
    public void collided()
    {
       lives--;
    }
    public boolean getPause()
    {
       return pause; 
    }
    public void pauseGame(boolean paused)
    {
       pause = paused;
    }
}
