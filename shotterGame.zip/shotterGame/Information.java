import greenfoot.*;  

public class Information  extends Actor
{
    
    public void act() 
    {
        click();
    }    
    public void click()
    {
       if(Greenfoot.mouseClicked(null))
       {
          ((CarWorld) getWorld()).pauseGame(false);
          getWorld().removeObject(this);
       }
    }
}
