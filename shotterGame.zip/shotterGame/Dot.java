import greenfoot.*;  

public class Dot  extends Actor
{
    private int counter = 0;
    
    public void act() 
    {
        moveUp();
        checkLocation();
    }    
    public void moveUp()
    {
       if(((CarWorld) getWorld()).getPause() == false)
       {
          if(counter == 0)
          {
             setLocation(getX(), getY()-1);
             counter = 30;
          }
          else
          {
             counter--;
          }
       }
    }
    public void checkLocation()
    {
       if(getY() == 117)
       {
          setLocation(getX(), getY()-1);
          getWorld().addObject(new EndLine(), 307, 0);
       }
    }
}
