import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Gear here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Gear extends Tank
{
    public static int value = 0;
    public static int target;
    public static String text;
    public static int stringLength;
    public static int gear;
    public static int target2;
    public Gear()
    {
        this("");
    }
    public Gear(String prefix)
    {
        value = 0;
        target = 0;
        text = prefix;
        stringLength = (text.length()+2) * 16;

        setImage(new GreenfootImage(stringLength, 24));
        GreenfootImage image = getImage();
        Font font = image.getFont();
        image.setFont(font.deriveFont(24.0F));  // use larger font
        
        updateImage();
    }
    public void act()
    {
       target = ((CarWorld) getWorld()).getSpeed();
       target2 = ((CarWorld) getWorld()).getGear();
       if(value > target)
       {
          value = 0;

          updateImage();
       }
       accelerate(target);
       updateImage();
       
    }
    public void add(int score)
    {
        target += score;
    }
    public int getValue()
    {
        return value;
    }
    public void updateImage()
    {
        GreenfootImage image = getImage();
        image.clear();
        image.drawString(text + target2 , 1, 18);
    }
}
