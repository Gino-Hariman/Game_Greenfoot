import greenfoot.*;  


public class EndLine  extends Actor
{
   
    public void act() 
    {
        moveDown();
        checkLocation();
    }    
    public void moveDown()
    {
       setLocation(getX(), getY()+4);
    }
    public void checkLocation()
    {
       if (getY()>=(getWorld().getHeight()-1))
       {
          Greenfoot.stop();
          getWorld().addObject(new ScoreBoard(),300,300);
          getWorld().removeObject(this);
       }
    }
}
