import greenfoot.*;

public class CountSpeed extends Actor
{
    public static int value = 0;
    private static int target = 0;
    public static String text;
    public static int stringLength;
    public CountSpeed()
    {
        this("");
    }
    public CountSpeed(String prefix)
    {
        value = 0;
        target = 0;
        text = prefix;
        stringLength = (text.length() + 2) * 16;

        setImage(new GreenfootImage(stringLength, 24));
        GreenfootImage image = getImage();
        Font font = image.getFont();
        image.setFont(font.deriveFont(24.0F));  // use larger font
        
        updateImage();
    }
    public void act()
    {
       target = ((CarWorld) getWorld()).getSpeed();
       if(target >= 400)
       {
          target = 400;
          updateImage();
       }
       if(target <= 0){
           target =20;
           updateImage();
       }
       
       updateImage();
    }
    public void updateImage()
    {
        GreenfootImage image = getImage();
        image.clear();
        image.drawString(target+text, 1, 18);
    }    
    public int getTarget()
    {
        return this.target;
    }
}
